Configuration Adduserstogroup {

    param (
        [Parameter(Mandatory)]
        [String]$GroupName,

        [Parameter(Mandatory)]
        [String[]]$MembersToInclude,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential] $Credentials
    )
    $DomainCreds = New-Object System.Management.Automation.PSCredential($Credentials.username,$Credentials.password)

    Import-DscResource -ModuleName PSDesiredStateConfiguration    
 
    node localhost{
        Group AddAdmin{
            GroupName = $GroupName
            Ensure = 'Present'
            Credential = $DomainCreds
            MembersToInclude = $MembersToInclude
        }
 
    }
}