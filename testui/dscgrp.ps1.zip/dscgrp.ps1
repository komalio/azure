Configuration AddDomainUsers
{
    param (

        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [String]$GroupName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds

        )

    $DCredential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList ("$DomainName\$($Admincreds.Username)", $Admincreds.Password)
 
    Node localhost{
        Group AddDomainUsers{
            GroupName = $GroupName
            Ensure = "Present"
            MembersToInclude = @("pratest\test1", "pratest\test2", "pratest\komali")
            Credential = $DCredential
            PsDscRunAsCredential = $DCredential
        }
        LocalConfigurationManager            
        {            
             RebootNodeIfNeeded = $true          
        }
 
    }
}