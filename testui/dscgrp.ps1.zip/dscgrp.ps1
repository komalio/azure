Configuration Adduserstogroup {

    param (
        [String]$GroupName,
        
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential] $Credentials

        )
    
    $DomainCreds = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList ("$DomainName\$($Credential.Username)", $Credential.Password)

    Import-DscResource -ModuleName PSDesiredStateConfiguration    
 
    node localhost{
        Group AddAdmin{
            GroupName = $GroupName
            Ensure = 'Present'
            Credential = $DomainCreds
            MembersToInclude = @('pratest\test1','pratest\test2','pratest\komali')
        }
        LocalConfigurationManager            
        {            
             ActionAfterReboot = 'ContinueConfiguration' 
             RebootNodeIfNeeded = $true            
        }
 
    }
}