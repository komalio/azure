Configuration Adduserstogroup {

    param (

        [Parameter(Mandatory)]
        [String]$GroupName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Credentials

        )

    Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope LocalMachine

    $DomainCreds = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList ($Credentials.Username, $Credentials.Password)

    Import-DscResource -ModuleName PSDesiredStateConfiguration    
 
    node prawintest{
        Group AddAdmin{
            GroupName = $GroupName
            Ensure = 'Present'
            MembersToInclude = @('pratest\test1','pratest\test2','pratest\komali')
            Credential = $DomainCreds
        }
        LocalConfigurationManager            
        {            
             ActionAfterReboot = 'ContinueConfiguration' 
             RebootNodeIfNeeded = $true            
        }
 
    }
}