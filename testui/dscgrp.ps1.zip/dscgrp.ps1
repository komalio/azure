Configuration Adduserstogroup {

    param (
        [Parameter(Mandatory)]
        [String]$GroupName,

        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [String[]]$MembersToInclude,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential] $Credentials
    )
        [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Credentials.UserName)", $Credentials.Password)

    Import-DscResource -ModuleName PSDesiredStateConfiguration    
 
    node localhost{
        Group AddAdmin{
            GroupName = $GroupName
            Ensure = 'Present'
            Credential = $DomainCreds
            MembersToInclude = $MembersToInclude
        }
        LocalConfigurationManager            
        {            
             ActionAfterReboot = 'ContinueConfiguration' 
             RebootNodeIfNeeded = $true            
        }
 
    }
}