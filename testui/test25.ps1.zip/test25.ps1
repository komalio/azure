class
 
configuration UserConfig{
    param(
        [System.Management.Automation.PSCredential]$DomainCredential
    )
 
    Import-DscResource -ModuleName PSDesiredStateConfiguration    
 
    node $AllNodes.NodeName{
 
        Group Admin{
            GroupName = 'Administrators'
            Ensure = 'Present'
            Credential = $DomainCredential
            Members = @('pratest\test1','pratest\test2')
        }
 
    }
}
 
$configData = @{
    AllNodes = @(
        @{
            NodeName = 'prawintest'
            PSDscAllowPlainTextPassword = $true
            PSDscAllowDomainUser = $true
        }
    )
}
 
$cred = Get-Credential -UserName pratest\komali -Message "bitc@1234"
UserConfig -DomainCredential $cred -ConfigurationData $configData
