@{
    AllNodes = @(
        @{
            NodeName = '*';
            DomainName = 'ad.pratest.com';
         }
        @{
            NodeName = 'prawintest';
            AdminAccount = 'test1'
        }
    )
}

$domain = $node.DomainName.split('.')[0]
$DCredential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList ("pratest\komali", bitc@1234)

Group AddADUserToAdminGroup {
    GroupName='Remote'
    Ensure= 'Present'
    MembersToInclude= "$domain\$($Node.AdminAccount)"
    Credential = $dCredential
    PsDscRunAsCredential = $DCredential
}