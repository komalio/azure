 param
   (
       
        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$credential
   )
@{
    AllNodes = @(
        @{
            NodeName = '*';
            DomainName = 'ad.pratest.com';
         }
        @{
            NodeName = 'prawintest';
            AdminAccount = 'test1'
        }
    )
}
$userName = 'pratest\komali'
$password = ConvertTo-SecureString 'bitc@1234' -AsPlainText -Forced
$domain = $node.DomainName.split('.')[0]
$DCredential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList ("$domain\$($credential.Username)", $credential.Password)

Group AddADUserToAdminGroup {
    GroupName='Administrators'
    Ensure= 'Present'
    MembersToInclude= "$domain\$($Node.AdminAccount)"
    Credential = $dCredential
    PsDscRunAsCredential = $DCredential
}