configuration GroupTest
{   
    param(
        [System.Management.Automation.PSCredential]$DomainCredential
    )
    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Node localhost
    {
        GroupSet GroupTest
        {
            GroupName        = @("Administrators")
            Ensure           = "Present"
            MembersToInclude = @("ad.pratest.com\test1", "ad.pratest.com\test2")
            Credential       = $DomainCredential
        }
    }
}