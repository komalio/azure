Configuration AddDomainUsers
{
    param (

        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [String]$GroupName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds

        )

    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)

    Import-DscResource -ModuleName PSDesiredStateConfiguration    
 
    node localhost{

        Group AddAdmin{
            GroupName = $GroupName
            Ensure = "Present"
            MembersToInclude = @("pratest\test1","pratest\test2","pratest\komali")
            Credential = $DomainCreds
        }
        LocalConfigurationManager            
        {            
             ActionAfterReboot = 'ContinueConfiguration' 
             RebootNodeIfNeeded = $true          
        }
 
    }
}