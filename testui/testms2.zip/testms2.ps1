$password = "Password@1234" | ConvertTo-SecureString -asPlainText -Force
$username = "pratest\adminuser"
[PSCredential] $credential = New-Object System.Management.Automation.PSCredential($username,$password)

Configuration DomainCredential
{
    Import-DscResource -ModuleName PSDesiredStateConfiguration

    node localhost
    {
        Group DomainUserToLocalGroup
        {
            GroupName        = 'RemoteDesktopUsers'
            MembersToInclude = 'pratest\test1'
            Credential       = $credential
        }
    }
}

$cd = @{
    AllNodes = @(
        @{
            NodeName = 'prawintest'
            PSDscAllowPlainTextPassword = $true
        }
    )
}

DomainCredential -ConfigurationData $cd