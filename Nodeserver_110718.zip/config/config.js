module.exports = {

    iot: {
        hubUri: process.env.iotHubUri,
        dpsUri: process.env.dpsConnection
    }
}