import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'areaMarkingSlider',
  templateUrl: './area-marking-slider.component.html',
  styleUrls: ['./area-marking-slider.component.css']
})
export class AreaMarkingSliderComponent implements OnInit {

  stageHere = 3;
  constructor() { }

  ngOnInit() {
  }

}
