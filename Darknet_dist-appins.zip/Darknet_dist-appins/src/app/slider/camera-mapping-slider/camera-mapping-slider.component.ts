import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cameraMappingSlider',
  templateUrl: './camera-mapping-slider.component.html',
  styleUrls: ['./camera-mapping-slider.component.css']
})
export class CameraMappingSliderComponent implements OnInit {

  stageHere=2;
  constructor() { }

  ngOnInit() {
  }

}
