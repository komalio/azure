export class Contact{

    name: string;

    constructor(name){
        this.name = name;
    
    }
}