import { NgModule } from '@angular/core';
import { FormsModule }   from '@angular/forms';

//import { ConnectCameraComponent } from '../../components/connect-camera/connect-camera.component';

@NgModule({
    imports: [
        FormsModule
    ],
    declarations: [],
})
export class CameraManagementModule { }