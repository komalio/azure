import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'areaMarkingDashboard',
  templateUrl: './area-marking-onboarding.component.html',
  styleUrls: ['./area-marking-onboarding.component.css']
})
export class AreaMarkingOnboardingComponent implements OnInit {

  stageHere = 4;
  constructor() { }

  ngOnInit() {
  }

}
