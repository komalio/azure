import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'connectCameraDashboard',
  templateUrl: './connect-camera-onboarding.component.html',
  styleUrls: ['./connect-camera-onboarding.component.css']
})
export class ConnectCameraOnboardingComponent implements OnInit {

  stageHere = 5;
  constructor() { }

  ngOnInit() {
  }

}
