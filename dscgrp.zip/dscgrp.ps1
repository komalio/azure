class

configuration UserConfig{
    param(
        [System.Management.Automation.PSCredential]$DomainCredential
    )
 
    Import-DscResource -ModuleName PSDesiredStateConfiguration    
 
    node $AllNodes.NodeName{
        Group TestAdmin
        {
	       GroupName = 'TestAdmin'
	       Ensure = 'Present'
           Credential = $DomainCredential
	       Members = @('pratest\test1','pratest\test2','pratest\komali')
        }
        Group AddAdmin{
            GroupName = 'RemoteDesktopUsers'
            Ensure = 'Present'
            Credential = $DomainCredential
            MembersToInclude = 'TestAdmin'
            DependsOn = '[Group]TestAdmin'
        }
 
    }
}
 
$configData = @{
    AllNodes = @(
        @{
            NodeName = 'prawintest'
            PSDscAllowPlainTextPassword = $true
            PSDscAllowDomainUser = $true
        }
    )
}
 
$cred = Get-Credential -UserName domain\komali -Message "bitc@1234"
UserConfig -DomainCredential $cred -ConfigurationData $configData
